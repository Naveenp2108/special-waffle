#include "log.h"
#include "eeprom.h"
#include "clcd.h"
#define _XTAL_FREQ 20000000
#include <xc.h>
#include "switch.h"

static unsigned char idx=0;

void log_event(unsigned char ev, unsigned char sp)
{
    unsigned char addr = idx*5;

    eeprom_write(addr++,12);
    eeprom_write(addr++,30);
    eeprom_write(addr++,45);
    eeprom_write(addr++,ev);
    eeprom_write(addr++,sp);

    idx++;
    if(idx>=10) idx=0;
}

void view_logs(void)
{
    static unsigned char i=0;
    unsigned char addr=i*5;

    unsigned char h=eeprom_read(addr++);
    unsigned char m=eeprom_read(addr++);
    unsigned char s=eeprom_read(addr++);
    unsigned char sp=eeprom_read(addr+1);

    clcd_print("LOG",0x80);

    clcd_putch(h/10+'0',0xC0);
    clcd_putch(h%10+'0',0xC1);

    clcd_putch(sp/10+'0',0xC4);
    clcd_putch(sp%10+'0',0xC5);

    if(RD2==0)
    {
        i++;
        if(i>=10) i=0;
        __delay_ms(300);
    }
}

void clear_logs(void)
{
    for(int i=0;i<50;i++)
        eeprom_write(i,0xFF);

    clcd_print("CLEARED",0x80);
    __delay_ms(1000);
}

void dashboard(unsigned char h, unsigned char m, unsigned char s, unsigned char speed)
{
    clcd_print("TIME EV SP", 0x80);

    clcd_putch((h/10)+'0',0xC0);
    clcd_putch((h%10)+'0',0xC1);
    clcd_putch(':',0xC2);

    clcd_putch((m/10)+'0',0xC3);
    clcd_putch((m%10)+'0',0xC4);
    clcd_putch(':',0xC5);

    clcd_putch((s/10)+'0',0xC6);
    clcd_putch((s%10)+'0',0xC7);

    clcd_putch(' ',0xC8);

    clcd_putch((speed/10)+'0',0xCC);
    clcd_putch((speed%10)+'0',0xCD);
}