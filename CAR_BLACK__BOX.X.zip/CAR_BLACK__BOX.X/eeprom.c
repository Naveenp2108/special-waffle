#include "eeprom.h"
#define _XTAL_FREQ 20000000
#include <xc.h>
#include "i2c.h"

#define ADDR 0xA0

void eeprom_write(unsigned char a,unsigned char d)
{
    i2c_start();
    i2c_write(ADDR);
    i2c_write(a);
    i2c_write(d);
    i2c_stop();
    __delay_ms(10);
}

unsigned char eeprom_read(unsigned char a)
{
    unsigned char d;
    i2c_start();
    i2c_write(ADDR);
    i2c_write(a);
    i2c_start();
    i2c_write(ADDR|1);
    d=i2c_read();
    i2c_stop();
    return d;
}