#include <xc.h>
#define _XTAL_FREQ 20000000
#include "clcd.h"

void init_clcd(void){}
void clcd_print(const char *s,unsigned char a){}
void clcd_putch(char d,unsigned char a){}