#define _XTAL_FREQ 20000000
#include <xc.h>
#include "password.h"
#include "clcd.h"
#include "switch.h"

unsigned char stored[4]={1,2,3,4};

unsigned char password_check(void)
{
    unsigned char entered[4]={0};
    unsigned char i=0, attempts=0;

    while(attempts<3)
    {
        clcd_print("ENTER PASS",0x80);

        for(i=0;i<4;)
        {
            if(read_switch(SW4)==PRESSED)
            {
                entered[i]++;
                if(entered[i]>9) entered[i]=0;
                clcd_putch('*',0xC0+i);
                __delay_ms(200);
            }

            if(read_switch(SW5)==PRESSED)
            {
                i++;
                __delay_ms(200);
            }
        }

        for(i=0;i<4;i++)
            if(entered[i]!=stored[i])
                break;

        if(i==4) return 1;

        attempts++;
        clcd_print("WRONG",0x80);
        __delay_ms(1000);
    }
    return 0;
}