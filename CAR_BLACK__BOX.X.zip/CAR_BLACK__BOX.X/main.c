#define _XTAL_FREQ 20000000
#include <xc.h>
#include "log.h"
#pragma config WDTE = OFF
#pragma config FOSC = HS


#include "clcd.h"
#include "adc.h"
#include "i2c.h"
#include "rtc.h"
#include "eeprom.h"
#include "switch.h"
#include "password.h"
#include "menu.h"
#include "log.h"

typedef enum {
    DASHBOARD,
    PASSWORD,
    MENU,
    VIEW_LOG,
    CLEAR_LOG
} state_t;

state_t state = DASHBOARD;

unsigned char h,m,s,speed;

void main(void)
{
    init_clcd();
    init_adc();
    init_i2c();
    init_switch();

    while(1)
    {
        get_time(&h,&m,&s);
        speed = (read_adc()*99)/1023;

        switch(state)
        {
            case DASHBOARD:
                dashboard(h,m,s,speed);

                if(RD0==0) log_event(5,speed);
                if(RD1==0) log_event(1,speed);

                if(RD2==0)
                {
                    state = PASSWORD;
                    __delay_ms(300);
                }
                break;

            case PASSWORD:
                if(password_check())
                    state = MENU;
                else
                    state = DASHBOARD;
                break;

            case MENU:
            {
                unsigned char sel = menu_run();
                if(sel==0) state = VIEW_LOG;
                if(sel==1) state = CLEAR_LOG;
                break;
            }

            case VIEW_LOG:
                view_logs();
                if(RD3==0) state = MENU;
                break;

            case CLEAR_LOG:
                clear_logs();
                state = MENU;
                break;
        }
    }
}
