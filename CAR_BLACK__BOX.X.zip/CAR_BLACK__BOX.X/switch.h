
#ifndef SWITCH_H
#define SWITCH_H

#define SW4 0
#define SW5 1

#define PRESSED 1
#define RELEASED 0

void init_switch(void);
unsigned char read_switch(unsigned char sw);

#endif