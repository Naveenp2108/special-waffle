#include "switch.h"
#define _XTAL_FREQ 20000000
#include <xc.h>

void init_switch(void)
{
    TRISD = 0xFF;
}

unsigned char read_switch(unsigned char sw)
{
    if(sw==SW4) return RD2==0;
    if(sw==SW5) return RD3==0;
    return 0;
}