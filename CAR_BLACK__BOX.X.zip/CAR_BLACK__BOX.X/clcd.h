#ifndef CLCD_H
#define CLCD_H

void init_clcd(void);
void clcd_print(const char *, unsigned char);
void clcd_putch(char, unsigned char);

#endif