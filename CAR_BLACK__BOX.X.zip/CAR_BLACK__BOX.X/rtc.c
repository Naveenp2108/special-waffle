#include "rtc.h"
#include <xc.h>
#define _XTAL_FREQ 20000000

void get_time(unsigned char *h,unsigned char *m,unsigned char *s)
{
    *h=12; *m=30; *s=45;
}