#include <xc.h>
#define _XTAL_FREQ 20000000
#include "i2c.h"

void init_i2c(void)
{
    SSPCON=0x28;
    SSPADD=49;
}

void i2c_start(void){SEN=1; while(SEN);}
void i2c_stop(void){PEN=1; while(PEN);}
void i2c_write(unsigned char d){SSPBUF=d; while(BF);}
unsigned char i2c_read(void){RCEN=1; while(!BF); return SSPBUF;}