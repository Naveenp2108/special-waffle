
#ifndef PASSWORD_H
#define PASSWORD_H

unsigned char password_check(void);

#endif