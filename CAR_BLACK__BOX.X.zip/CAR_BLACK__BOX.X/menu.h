#ifndef MENU_H
#define MENU_H

unsigned char menu_run(void);

#endif