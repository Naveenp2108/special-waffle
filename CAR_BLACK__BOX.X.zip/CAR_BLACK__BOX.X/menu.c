#define _XTAL_FREQ 20000000
#include "menu.h"
#include "clcd.h"
#include "switch.h"
#include <xc.h>

unsigned char menu_run(void)
{
    static unsigned char index=0;

    clcd_print("MENU",0x80);

    if(index==0) clcd_print(">View Log",0xC0);
    if(index==1) clcd_print(">Clear Log",0xC0);

    if(read_switch(SW4)==PRESSED)
    {
        index = (index+1)%2;
        __delay_ms(200);
    }

    if(read_switch(SW5)==PRESSED)
    {
        return index;
    }

    return 255;
}