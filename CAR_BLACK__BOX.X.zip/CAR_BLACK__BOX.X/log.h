#ifndef LOG_H
#define LOG_H

void log_event(unsigned char, unsigned char);
void view_logs(void);
void clear_logs(void);
void dashboard(unsigned char h, unsigned char m, unsigned char s, unsigned char speed);

#endif