
#include <xc.h>
#define _XTAL_FREQ 20000000
#include "adc.h"

void init_adc(void)
{
    ADCON0=0x01;
    ADCON1=0x80;
}

unsigned int read_adc(void)
{
    GO=1;
    while(GO);
    return ((ADRESH<<8)|ADRESL);
}