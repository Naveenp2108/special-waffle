#ifndef RTC_H
#define RTC_H

void get_time(unsigned char *, unsigned char *, unsigned char *);

#endif